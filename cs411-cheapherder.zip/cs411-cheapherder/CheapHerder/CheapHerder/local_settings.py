# Grabs the site root setup in settings.py
import os
from settings import *
 
DEBUG = True


DATABASES = {
    'default': {
       	'ENGINE': 'django.db.backends.postgresql_psycopg2',
       	'NAME': 'cheapherder',
   	    'USER': 'admin',
        'PASSWORD': 'hussein@1',
        'HOST': 'localhost',
        'PORT': '',
    }
}

CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "asgiref.inmemory.ChannelLayer",
        "ROUTING": "CheapHerder.routing.channel_routing",
    },
}